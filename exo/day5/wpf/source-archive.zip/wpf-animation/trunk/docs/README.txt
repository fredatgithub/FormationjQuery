Look or Feel Animation classes

GETTING STARTED

If you want to run the sample application in Visual Studio, be sure to set AnimationTester as your startup project.

Watch this space for more info. 